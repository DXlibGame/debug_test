#pragma once

extern void Stage1();
